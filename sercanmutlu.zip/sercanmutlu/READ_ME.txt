T�rk�e:
Oyunumuzda iki a�ama vard�r. Bu a�amalardan ilki bilgisayar�n say� tuttu�u ve sizin tahmin etmeye �al��t���n�z a�amad�r.
Bu a�amada sizden beklenen bilgisayar�n tuttu�u d�rt basamakl� rakamlar� farkl� say�y� en az tahminde bilmenizdir.
Tahminler sonucunda
tutulan say� ile ilgili ipu�lar� verilecek. E�er tahmin edilen say� i�inde tutulan say�n�n rakamlar�ndan varsa
ve basamak de�eri do�ruysa �+� de�er olarak ipucu verilecek, basamak de�eri yanl�� ise �-� de�er ipucu
olarak verilecektir. �rne�in bilgisayar 5483 say�s�n� tutsun ve kullan�c� 3468 tahmini yapt���nda 4 say�s�n�n
basamak de�eri do�ru oldu�u i�in +1, 3 ve 8 say�s�n�n basamak de�eri yanl�� oldu�u i�in -2 de�eri
d�n�lecektir. 
Oyunun ikinci a�amas�nda ise sizin tuttu�unuz say�y� bilgisayar bilmeye �al��acakt�r ve siz bilgisayara ipucu vereceksiniz.
E�er yanl�� ipucu verirseniz bilgisayar bu soruyu ��zemeyecektir.
L�tfen ipu�lar�n� do�ru vermeye �zen g�steriniz.

English:
There are two stages in our game. The first is the stage which the computer keeps a number and you are trying to guess.
At this stage, you should find the four unique digits number with AZ prediction.
As a result of guesses, hints on the number being held. If there are any numbers of numbers held within the estimated number
and if the value of the digit is correct, a clue will be given as a  + value else if the value of the digit is incorrect, a clue will be given as a  - value.
For example, the computer can hold the number 5483 and the user makes 3468
It will return -2 +1 hint , because the value of the digit 4 is correct it will return +1 ,but because the value of the number of digits 3 and 8 is incorrect it will return -2.
In the second phase of the game, you will try to know the number you are holding, and you will give a hint to the computer. 
If you give the wrong tip, the computer will not be able to solve this question.
Please take care to give your tips correctly.